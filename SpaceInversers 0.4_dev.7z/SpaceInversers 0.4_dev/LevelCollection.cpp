#include "LevelCollection.h"

LevelCollection::LevelCollection() : levels() {}

LevelCollection::~LevelCollection() {}

LevelCollection::getLevel(uint it)