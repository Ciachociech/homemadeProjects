#include "Instance.h"

int main()
{
	Instance instance;
	instance.launch();
	return 0;
}